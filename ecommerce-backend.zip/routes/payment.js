const router = require("express").Router();
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

router.post("/stripe", async (req, res) => {
  const { amount, token } = req.body;
  try {
    const charge = await stripe.charges.create({
      amount,
      currency: "usd",
      source: token,
      description: "E-commerce payment"
    });
    res.json(charge);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
